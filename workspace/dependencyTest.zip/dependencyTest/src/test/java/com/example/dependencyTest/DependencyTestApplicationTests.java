package com.example.dependencyTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependencyTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
